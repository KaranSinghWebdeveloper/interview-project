import AuthenticatedLayout from '../Layouts/AuthenticatedLayout';
import React, { useState, useEffect } from 'react';
import { useForm } from '@inertiajs/inertia-react';
import { Head, usePage } from '@inertiajs/react';

const FollowUpIndex = ({ followUps, users }) => {
    const [isOpen, setIsOpen] = useState(false);

    // const { auth } = usePage().props;
    const user_data = usePage().props.auth.user;
    // console.log(user_data)

    const { data, setData, post, reset } = useForm({
        user_id: '',
        message: '',
        followup_at: '',
        sender_user_id: user_data.id,
    });

    useEffect(() => {
        const currentDateTime = new Date().toISOString().slice(0, 16);
        setData('followup_at', currentDateTime);
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setData(name, value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        post('/followups', {
            user_id: data.user_id,
            message: data.message,
            followup_at: data.followup_at,
            sender_user_id: data.sender_user_id,
        });
        setIsOpen(false);
        reset();
    };

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this follow-up?')) {
            post(`/followups/${id}`, {
                _method: 'DELETE',
            });
        }
    };

    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Chat Boat
                </h2>
            }
        >
            <Head title="Chat Boat" />
            <div className="p-12">
                <div>
                    <h2 className="text-2xl font-semibold mb-4">Follow-Up List</h2>

                    <button onClick={() => setIsOpen(true)} className="mb-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                        Add Follow-Up
                    </button>

                    <div className="space-y-4 px-4 sm:px-10">
                        {followUps.map((followUp) => {
                            const isSender = followUp.sender_user_id == user_data.id;

                            return (
                                <div
                                    key={followUp.id}
                                    className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`p-3 sm:p-4 rounded-lg shadow-md w-[80%] sm:max-w-md ${isSender
                                            ? 'bg-blue-500 text-white rounded-br-none'
                                            : 'bg-gray-200 text-gray-800 rounded-bl-none'
                                            }`}
                                    >
                                        <p className="text-sm font-semibold mb-1">
                                            {followUp.user.name}
                                        </p>
                                        <p className="text-base break-words">{followUp.message}</p>
                                        <p className="text-xs text-right mt-2 opacity-70">
                                            {new Date(followUp.followup_at).toLocaleString()}
                                        </p>
                                        {isSender && (
                                            <div className="text-right mt-2">
                                                <button
                                                    onClick={() => handleDelete(followUp.id)}
                                                    className="text-xs text-white underline hover:text-gray-100"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>



                    {isOpen && (
                        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
                            <div className="bg-white p-6 rounded-lg shadow-lg w-96">
                                <h3 className="text-xl font-semibold mb-4">Add New Follow-Up</h3>
                                <form onSubmit={handleSubmit}>
                                    <div className="mb-4">
                                        <label htmlFor="user_id" className="block text-sm font-medium text-gray-700">User</label>
                                        <select
                                            id="user_id"
                                            name="user_id"
                                            value={data.user_id}
                                            onChange={handleInputChange}
                                            className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                            required
                                        >
                                            <option value="">Select User</option>
                                            {users.filter((user) => user.id != user_data.id)
                                                .map((user) => (
                                                    <option key={user.id} value={user.id}>
                                                        {user.name} ({user.id})
                                                    </option>
                                                ))}
                                        </select>
                                    </div>
                                    <div className="mb-4">
                                        <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                                        <textarea
                                            id="message"
                                            name="message"
                                            value={data.message}
                                            onChange={handleInputChange}
                                            className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                            required
                                        />
                                    </div>
                                    <div className="mb-4">
                                        <label htmlFor="followup_at" className="block text-sm font-medium text-gray-700">Follow-Up Date</label>
                                        <input
                                            type="datetime-local"
                                            id="followup_at"
                                            name="followup_at"
                                            value={data.followup_at}
                                            onChange={handleInputChange}
                                            className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                            required
                                        />
                                    </div>
                                    <div className="mb-4">
                                        {/* <label htmlFor="sender_user_id" className="block text-sm font-medium text-gray-700">Sender User ID</label> */}
                                        <input
                                            type="hidden"
                                            id="sender_user_id"
                                            name="sender_user_id"
                                            value={data.sender_user_id}
                                            onChange={handleInputChange}
                                            className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                            disabled
                                        />
                                    </div>
                                    <div className="flex justify-between">
                                        <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">Save</button>
                                        <button type="button" onClick={() => setIsOpen(false)} className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </AuthenticatedLayout>
    );
};

export default FollowUpIndex;
