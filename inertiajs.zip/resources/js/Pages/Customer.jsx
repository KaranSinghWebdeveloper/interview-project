import AuthenticatedLayout from '../Layouts/AuthenticatedLayout';
import { Head, usePage } from '@inertiajs/react';
import { useState } from 'react';
import { useForm } from '@inertiajs/inertia-react';

export default function Customer() {
    const { customers, status } = usePage().props;
    const [isOpen, setIsOpen] = useState(false);
    const [editMode, setEditMode] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState(null);

    const { data, setData, post, processing, reset, put } = useForm({
        first_name: '',
        last_name: '',
        age: '',
        dob: ''
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setData(name, value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (editMode) {
            put(`/customers/${editingCustomer.id}`, {
                first_name: data.first_name,
                last_name: data.last_name,
                age: data.age,
                dob: data.dob
            });
        } else {
            post('/customers', {
                first_name: data.first_name,
                last_name: data.last_name,
                age: data.age,
                dob: data.dob
            });
        }

        setIsOpen(false);
        reset();
        setEditMode(false);
        setEditingCustomer(null);
    };

    const handleEdit = (customer) => {
        setEditingCustomer(customer);
        setData({
            first_name: customer.first_name,
            last_name: customer.last_name,
            age: customer.age,
            dob: customer.dob
        });
        setEditMode(true);
        setIsOpen(true);
    };

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this customer?')) {
            post(`/customers/delete/${id}`);
        }
    };

    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Customers
                </h2>
            }
        >
            <Head title="Customer" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <h2 className="text-2xl font-semibold mb-4">Customer List</h2>

                            <button
                                onClick={() => setIsOpen(true)}
                                className="mb-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                            >
                                Add Customer
                            </button>

                            <table className="min-w-full bg-white border border-gray-300">
                                <thead>
                                    <tr>
                                        <th className="px-4 py-2 border-b text-left">ID</th>
                                        <th className="px-4 py-2 border-b text-left">First Name</th>
                                        <th className="px-4 py-2 border-b text-left">Last Name</th>
                                        <th className="px-4 py-2 border-b text-left">Age</th>
                                        <th className="px-4 py-2 border-b text-left">Date of Birth</th>
                                        <th className="px-4 py-2 border-b text-left">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {customers.map((customer) => (
                                        <tr key={customer.id}>
                                            <td className="px-4 py-2 border-b">{customer.id}</td>
                                            <td className="px-4 py-2 border-b">{customer.first_name}</td>
                                            <td className="px-4 py-2 border-b">{customer.last_name}</td>
                                            <td className="px-4 py-2 border-b">{customer.age}</td>
                                            <td className="px-4 py-2 border-b">{customer.dob}</td>
                                            <td className="px-4 py-2 border-b">
                                                <button
                                                    onClick={() => handleEdit(customer)}
                                                    className="px-2 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600 mr-2"
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    onClick={() => handleDelete(customer.id)}
                                                    className="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {isOpen && (
                    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
                        <div className="bg-white p-6 rounded-lg shadow-lg w-96">
                            <h3 className="text-xl font-semibold mb-4">
                                {editMode ? 'Edit Customer' : 'Add New Customer'}
                            </h3>
                            <form onSubmit={handleSubmit}>
                                <div className="mb-4">
                                    <label htmlFor="first_name" className="block text-sm font-medium text-gray-700">
                                        First Name
                                    </label>
                                    <input
                                        type="text"
                                        id="first_name"
                                        name="first_name"
                                        value={data.first_name}
                                        onChange={handleInputChange}
                                        className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                        required
                                    />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="last_name" className="block text-sm font-medium text-gray-700">
                                        Last Name
                                    </label>
                                    <input
                                        type="text"
                                        id="last_name"
                                        name="last_name"
                                        value={data.last_name}
                                        onChange={handleInputChange}
                                        className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                        required
                                    />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="age" className="block text-sm font-medium text-gray-700">
                                        Age
                                    </label>
                                    <input
                                        type="number"
                                        id="age"
                                        name="age"
                                        value={data.age}
                                        onChange={handleInputChange}
                                        className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                        required
                                    />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="dob" className="block text-sm font-medium text-gray-700">
                                        Date of Birth
                                    </label>
                                    <input
                                        type="date"
                                        id="dob"
                                        name="dob"
                                        value={data.dob}
                                        onChange={handleInputChange}
                                        className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                                        required
                                    />
                                </div>
                                <div className="flex justify-end">
                                    <button
                                        type="button"
                                        onClick={() => setIsOpen(false)}
                                        className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 mr-2"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                                        disabled={processing}
                                    >
                                        {processing ? 'Saving...' : editMode ? 'Update Customer' : 'Add Customer'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
            </div>
        </AuthenticatedLayout>
    );
}
