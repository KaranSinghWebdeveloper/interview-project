<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $customers = Customer::all();
        return Inertia::render('Customer', [
            'customers' => $customers,
            'status' => session('status'),
        ]);
    }

    public function store(Request $request)
    {
        $customer = Customer::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'age' => $request->age,
            'dob' => $request->dob,
        ]);

        $customers = Customer::all();

        return redirect()->route('customers')->with('success', 'Customer created.');

        // return Inertia::render('Customer', [
        //     'customers' => $customers,
        //     'status' => 'Customer added successfully!',
        // ]);
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::where('id', $id)->update([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'age' => $request->age,
            'dob' => $request->dob,
        ]);

        $customers = Customer::all();

        return redirect()->route('customers')->with('success', 'Customer updated.');
    }

    public function delete($id)
    {
        $customer = Customer::findOrFail($id);
        $customer->delete();

        return redirect()->route('customers')->with('success', 'Customer deleted successfully!');
        // return Inertia::render('Customer', [
        //     'customers' => Customer::all(),
        //     'status' => 'Customer deleted successfully!',
        // ]);
    }
}
