<?php

namespace App\Http\Controllers;

use App\Models\FollowUp;
use App\Models\User;
// use Illuminate\Container\Attributes\Auth;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;
use Inertia\Inertia;

class FollowUpController extends Controller
{
    public function index()
    {
        $followUps = FollowUp::with('user', 'sender')->latest()->get();
        return Inertia::render('FollowUps', [
            'followUps' => $followUps,
            'users' => User::all(),
            // 'auth' => Auth::id()
        ]);
    }

    public function store(Request $request)
    {

        $followUp = FollowUp::create([
            'user_id' => $request->user_id,
            'message' => $request->message,
            'followup_at' => $request->followup_at,
            'sender_user_id' => $request->sender_user_id,
        ]);

        return redirect()->route('followups.index')->with('status', 'Follow-up created successfully!');
    }

    public function update(Request $request, $id)
    {
        $followUp = FollowUp::findOrFail($id);

        $followUp->update([
            'message' => $request->message,
            'followup_at' => $request->followup_at,
        ]);

        return redirect()->route('followups.index')->with('status', 'Follow-up updated successfully!');
    }

    public function destroy($id)
    {
        $followUp = FollowUp::findOrFail($id);
        $followUp->delete();

        return redirect()->route('followups.index')->with('status', 'Follow-up deleted successfully!');
    }
}
